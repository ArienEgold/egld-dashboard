# ⚡ EGOLD Dashboard — MultiversX Live Tracker

Android-style live dashboard for EGLD/MultiversX with burn vs emit tracking, AI-powered news feed, and market sentiment analysis.

---

## 🚀 Deploy to Vercel (Step by Step)

### Step 1 — Install Node.js
Download from https://nodejs.org (choose LTS version)
Verify: open terminal and run `node -v`

### Step 2 — Install Git
Download from https://git-scm.com
Verify: `git --version`

### Step 3 — Create GitHub account
Go to https://github.com and sign up (free)

### Step 4 — Create a new GitHub repo
1. Click the **+** button → New repository
2. Name it: `egld-dashboard`
3. Set to **Public**
4. Click **Create repository**

### Step 5 — Push this project to GitHub
Open terminal in this folder and run:
```bash
git init
git add .
git commit -m "Initial EGLD dashboard"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/egld-dashboard.git
git push -u origin main
```
Replace YOUR_USERNAME with your GitHub username.

### Step 6 — Create Vercel account
Go to https://vercel.com → Sign up with GitHub (free)

### Step 7 — Deploy on Vercel
1. Click **Add New Project**
2. Import your `egld-dashboard` GitHub repo
3. Vercel auto-detects Vite — click **Deploy**
4. Wait ~60 seconds → your site is live! 🎉

### Step 8 — Add your API key (for live AI news)
1. In Vercel dashboard → your project → **Settings** → **Environment Variables**
2. Add:
   - Name: `VITE_ANTHROPIC_API_KEY`
   - Value: your key from https://console.anthropic.com
3. Click **Save** → go to **Deployments** → **Redeploy**

Get your Anthropic API key at: https://console.anthropic.com

---

## 💻 Run Locally

```bash
npm install
cp .env.example .env
# Edit .env and add your API key
npm run dev
```
Opens at http://localhost:5173

---

## 📁 Project Structure

```
egld-dashboard/
├── src/
│   ├── App.jsx        ← Main dashboard component
│   └── main.jsx       ← React entry point
├── index.html
├── vite.config.js
├── package.json
├── .env.example       ← Copy to .env and add your key
└── .gitignore
```

---

## Features
- 📊 Overview: price, ecosystem status, protocol metrics
- 🔥 Burn/Emit: live protocol math + 10-year projection chart
- 📰 News: AI-powered with VERIFIED/FAKE/MISLEADING labels
- 🌐 Network: validators, TPS, staking, tokenomics
- 🧠 Sentiment: fear & greed, price targets, risk matrix

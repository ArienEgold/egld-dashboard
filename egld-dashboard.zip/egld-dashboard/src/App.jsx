import { useState, useEffect } from "react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

// ─── PROTOCOL MATH ────────────────────────────────────────────────────────────
const SUPPLY = 28500000;
const GENESIS = new Date("2020-07-30");
function getY() { return (new Date() - GENESIS) / (1000 * 60 * 60 * 24 * 365.25); }
function infl(y) { return Math.max(0.02, 0.08757 - 0.0025 * y); }
function fbr(y) { return Math.min(0.5, 0.1 + 0.4 * (y / 8)); }
function getStats() {
  const y = getY(), i = infl(y), de = (SUPPLY * i) / 365, db = 80000 * 0.00005 * fbr(y);
  return {
    dailyEmit: de.toFixed(4), dailyBurn: db.toFixed(4),
    net: (de - db).toFixed(4), inflRate: (i * 100).toFixed(3),
    burnRatio: (fbr(y) * 100).toFixed(1),
    annualEmit: Math.round(SUPPLY * i).toLocaleString(), year: y.toFixed(2)
  };
}
function getChart() {
  return Array.from({ length: 21 }, (_, i) => {
    const y = i * 0.5;
    return { yr: `Y${y.toFixed(1)}`, emit: parseFloat(((SUPPLY * infl(y)) / 365).toFixed(2)), burn: parseFloat((80000 * 0.00005 * fbr(y)).toFixed(2)) };
  });
}

// ─── CONSTANTS ────────────────────────────────────────────────────────────────
const BADGE = {
  TRUE:        { label: "✔ VERIFIED",   bg: "#0d3d1f", border: "#00e676", color: "#00e676" },
  SEMITRUE:    { label: "◐ SEMI-TRUE",  bg: "#3d2d00", border: "#ffab00", color: "#ffab00" },
  UNVERIFIED:  { label: "? UNVERIF.",   bg: "#1a1a2e", border: "#7986cb", color: "#7986cb" },
  MISLEADING:  { label: "⚠ MISLEAD",   bg: "#3d1a00", border: "#ff6d00", color: "#ff6d00" },
  FAKE:        { label: "✗ FAKE",       bg: "#3d0000", border: "#ff1744", color: "#ff1744" },
  SPECULATIVE: { label: "~ SPECUL.",    bg: "#111",    border: "#78909c", color: "#78909c" },
};

const SRC = {
  "CoinTelegraph": "#f7931a", "MultiversX Official": "#00e4d0",
  "CryptoSlate": "#7b61ff",  "Reddit": "#ff4500",
  "Twitter/X": "#1d9bf0",    "CoinDesk": "#4353ff",
  "On-Chain Data": "#00e676","Dark Web Intel": "#ff1744",
  "Messari": "#a78bfa"
};

// ─── API CALL — reads key from .env ───────────────────────────────────────────
const API_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY || "";

async function fetchNews() {
  if (!API_KEY) {
    // Return demo data if no API key
    return DEMO_NEWS;
  }
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": API_KEY,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true"
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 2800,
      tools: [{ type: "web_search_20250305", name: "web_search" }],
      messages: [{
        role: "user",
        content: `You are an EGLD/MultiversX analyst. Generate 9 realistic news items for March 2026. Return ONLY raw JSON array no markdown:
[{"id":1,"title":"...","summary":"2 sentences","source":"CoinTelegraph","credibility":"TRUE","confidence":88,"timeAgo":"3h ago","reasoning":"why","priceImpact":"BULLISH","tags":["#Supernova"]}]
Sources: CoinTelegraph, MultiversX Official, CryptoSlate, Reddit, Twitter/X, On-Chain Data, Dark Web Intel, Messari.
Credibility: TRUE SEMITRUE UNVERIFIED MISLEADING FAKE SPECULATIVE — mix realistically.
Context: EGLD ~$4.10, down 99.3% from $545 ATH, Supernova testnet, Google UCP active, APR 6.5%.
Include 1 dark web rumor (FAKE/UNVERIFIED) and 1 misleading claim.`
      }]
    })
  });
  const data = await res.json();
  const text = data.content.map(b => b.type === "text" ? b.text : "").join("");
  const s = text.indexOf("["), e = text.lastIndexOf("]") + 1;
  return JSON.parse(text.slice(s, e));
}

// ─── DEMO NEWS (shown when no API key) ────────────────────────────────────────
const DEMO_NEWS = [
  { id:1, title:"MultiversX Supernova Testnet Passes 50,000 TPS Stress Test", summary:"The Supernova upgrade testnet successfully processed over 50,000 transactions per second during a coordinated stress test involving 200 validators. Core developers say mainnet launch is targeting Q3 2026.", source:"MultiversX Official", credibility:"TRUE", confidence:95, timeAgo:"2h ago", reasoning:"Direct from official MultiversX blog with transaction hashes verifiable on testnet explorer.", priceImpact:"BULLISH", tags:["#Supernova","#TPS","#Testnet"] },
  { id:2, title:"EGLD Price to Hit $50 by April 2026 — Analyst Claims 'Hidden Accumulation'", summary:"A pseudonymous analyst on Twitter claims whale wallets are accumulating EGLD quietly ahead of a major catalyst. The post went viral with 12,000 retweets but no on-chain evidence was provided.", source:"Twitter/X", credibility:"SPECULATIVE", confidence:22, timeAgo:"5h ago", reasoning:"No verifiable on-chain data supports the accumulation claim. Analyst has history of price predictions that did not materialize.", priceImpact:"BULLISH", tags:["#PricePrediction","#Whales"] },
  { id:3, title:"Google UCP Integration Now Handles 2.3M Daily AI Commerce Transactions on MVX", summary:"Google's Universal Commerce Protocol processed 2.3 million AI-assisted transactions on the MultiversX network in the past 24 hours. This represents a 40% week-over-week increase in UCP activity.", source:"On-Chain Data", credibility:"SEMITRUE", confidence:68, timeAgo:"8h ago", reasoning:"On-chain transaction count is verifiable but the '2.3M' figure bundles several transaction types. Pure UCP commerce txs are closer to 800K.", priceImpact:"BULLISH", tags:["#GoogleUCP","#AICommerce"] },
  { id:4, title:"EGLD Staking APR to Drop to 3% After Supernova — Developer Confirms", summary:"A MultiversX core developer confirmed in a community call that staking APR will decrease from 6.5% to approximately 3% post-Supernova due to reduced inflation. Long-term stakers expressed concern on Reddit.", source:"Reddit", credibility:"MISLEADING", confidence:55, timeAgo:"12h ago", reasoning:"The APR reduction is real but framed misleadingly — real yield improves because inflation drops faster than rewards, benefiting long-term holders.", priceImpact:"BEARISH", tags:["#Staking","#APR","#Supernova"] },
  { id:5, title:"Dark Web Forum Claims MultiversX Validator Key Exploit — No Evidence Found", summary:"A post on a dark web forum claims a critical validator key extraction vulnerability exists in MultiversX nodes, allegedly allowing private key theft. Security researchers found no proof of concept or affected validators.", source:"Dark Web Intel", credibility:"FAKE", confidence:8, timeAgo:"18h ago", reasoning:"Claim appears to be FUD designed to suppress price. MultiversX security team investigated and found no vulnerability. Likely a coordinated short attack.", priceImpact:"BEARISH", tags:["#Security","#FUD","#DarkWeb"] },
  { id:6, title:"MultiversX Q1 2026 Dev Activity Ranks Top 5 Among All L1 Blockchains", summary:"GitHub commit data aggregated by Messari shows MultiversX ranked 4th in developer activity among all Layer 1 blockchains in Q1 2026, with 1,847 commits across core repos. Only Ethereum, Solana, and Polkadot rank higher.", source:"Messari", credibility:"TRUE", confidence:91, timeAgo:"1d ago", reasoning:"Messari methodology is transparent and data matches public GitHub metrics. Ranking is independently verifiable.", priceImpact:"BULLISH", tags:["#DevActivity","#Fundamentals"] },
  { id:7, title:"EGLD Delisted From Second-Tier Exchange Amid Low Volume Concerns", summary:"CryptoExchange Pro announced it will delist EGLD trading pairs citing 30-day average volume below their minimum threshold. The exchange represents less than 0.8% of total EGLD trading volume.", source:"CryptoSlate", credibility:"TRUE", confidence:88, timeAgo:"1d ago", reasoning:"Confirmed via official exchange announcement. Impact is minimal given the exchange's tiny market share but signals weak retail interest.", priceImpact:"BEARISH", tags:["#Delisting","#Liquidity"] },
  { id:8, title:"MultiversX Partners With Major EU Bank for Tokenized Asset Settlement", summary:"A top-5 European bank has signed an MOU with MultiversX Foundation to pilot tokenized bond settlement on the network. The pilot involves €500M in government bonds and is set to begin in Q4 2026.", source:"CoinDesk", credibility:"UNVERIFIED", confidence:41, timeAgo:"2d ago", reasoning:"CoinDesk sourced this from a single anonymous insider. The bank name has not been disclosed and MultiversX Foundation has not officially confirmed.", priceImpact:"BULLISH", tags:["#Institutional","#TradFi","#Tokenization"] },
  { id:9, title:"EGLD Inflation Model Analysis: Tail Inflation Could Suppress Recovery Until 2028", summary:"A detailed tokenomics report argues that EGLD's 2% minimum inflation floor creates persistent sell pressure that may cap price recovery until burn mechanisms fully offset emissions. The report models breakeven at $8–12 price range.", source:"Messari", credibility:"SEMITRUE", confidence:72, timeAgo:"2d ago", reasoning:"Analysis is methodologically sound but uses conservative burn rate assumptions. If UCP transaction volume grows as projected, breakeven occurs much sooner.", priceImpact:"BEARISH", tags:["#Tokenomics","#Inflation","#Research"] },
];

// ─── COMPONENTS ───────────────────────────────────────────────────────────────
function Metric({ label, value, color, sub }) {
  return (
    <div style={{ background:"#050510", border:`1px solid ${color}20`, borderRadius:8, padding:10, borderLeft:`3px solid ${color}` }}>
      <div style={{ fontSize:9, letterSpacing:1.5, textTransform:"uppercase", color:"#455a64", marginBottom:3 }}>{label}</div>
      <div style={{ fontSize:17, fontWeight:800, color, letterSpacing:-0.3 }}>{value}</div>
      {sub && <div style={{ fontSize:10, color:"#2e3c44", marginTop:2 }}>{sub}</div>}
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("OVERVIEW");
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(false);
  const [exp, setExp] = useState(null);
  const [filter, setFilter] = useState("ALL");
  const [tick, setTick] = useState(0);
  const s = getStats(), cd = getChart();

  useEffect(() => { const t = setInterval(() => setTick(x => x + 1), 1000); return () => clearInterval(t); }, []);
  useEffect(() => { if (tab === "NEWS" && news.length === 0) load(); }, [tab]);

  async function load() {
    setLoading(true);
    try { setNews(await fetchNews()); } catch { setNews(DEMO_NEWS); }
    setLoading(false);
  }

  const now = new Date();
  const timeStr = `${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}:${String(now.getSeconds()).padStart(2,"0")}`;
  const fn = filter === "ALL" ? news : news.filter(n => n.credibility === filter);
  const card = { background:"linear-gradient(135deg,#0a0a18,#0d0d22)", border:"1px solid #1a1a35", borderRadius:12, padding:13 };
  const ct = { fontSize:9, fontWeight:700, letterSpacing:2, textTransform:"uppercase", color:"#455a64", marginBottom:10 };
  const g2 = { display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 };
  const TABS = ["OVERVIEW","BURN/EMIT","NEWS","NETWORK","SENTIMENT"];
  const BNAV = [{i:"📊",l:"Overview",t:"OVERVIEW"},{i:"🔥",l:"Burn/Emit",t:"BURN/EMIT"},{i:"📰",l:"News",t:"NEWS"},{i:"🌐",l:"Network",t:"NETWORK"},{i:"🧠",l:"Sentiment",t:"SENTIMENT"}];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@500;600;700&family=JetBrains+Mono:wght@400;700&display=swap');
        * { box-sizing:border-box; margin:0; padding:0; }
        body { background:#050508; }
        ::-webkit-scrollbar { width:3px; height:3px; }
        ::-webkit-scrollbar-thumb { background:#1a1a35; border-radius:2px; }
        @keyframes PL { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.3;transform:scale(1.6)} }
        @keyframes TK { 0%{transform:translateX(0)} 100%{transform:translateX(-50%)} }
        @keyframes SP { to{transform:rotate(360deg)} }
        @keyframes FD { from{opacity:0;transform:translateY(7px)} to{opacity:1;transform:translateY(0)} }
      `}</style>

      <div style={{ fontFamily:"'Rajdhani',sans-serif", background:"#050508", minHeight:"100vh", color:"#ddd", display:"flex", flexDirection:"column", maxWidth:460, margin:"0 auto", boxShadow:"0 0 80px #000" }}>

        {/* STATUS BAR */}
        <div style={{ background:"#07070f", padding:"3px 14px", display:"flex", justifyContent:"space-between", fontSize:10, color:"#455a64", borderBottom:"1px solid #0d0d1a" }}>
          <span>MultiversX · {timeStr}</span>
          <span style={{ display:"flex", alignItems:"center", gap:4 }}>
            <span style={{ width:6, height:6, borderRadius:"50%", background:"#00e676", boxShadow:"0 0 6px #00e676", display:"inline-block", animation:"PL 1.4s infinite" }}/>
            <span style={{ fontSize:9, color:"#00e676", letterSpacing:1 }}>LIVE</span>
          </span>
        </div>

        {/* TOP BAR */}
        <div style={{ background:"linear-gradient(180deg,#090918,#060612)", padding:"10px 14px 0", borderBottom:"1px solid #14142a" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:8 }}>
            <div style={{ display:"flex", alignItems:"center", gap:9 }}>
              <div style={{ width:36, height:36, borderRadius:9, background:"linear-gradient(135deg,#00e4d0,#00b8a9)", display:"flex", alignItems:"center", justifyContent:"center", fontWeight:900, fontSize:18, color:"#050508", boxShadow:"0 0 18px #00e4d055", flexShrink:0 }}>⚡</div>
              <div>
                <div style={{ fontSize:23, fontWeight:800, letterSpacing:2.5, color:"#fff", lineHeight:1 }}>EGOLD</div>
                <div style={{ fontSize:9, color:"#37474f", letterSpacing:1.5 }}>MULTIVERSX TRACKER</div>
              </div>
            </div>
            <div style={{ textAlign:"right" }}>
              <div style={{ display:"flex", alignItems:"baseline", gap:6, justifyContent:"flex-end" }}>
                <span style={{ fontSize:26, fontWeight:800, color:"#fff", letterSpacing:-0.5 }}>$4.10</span>
                <span style={{ fontSize:11, fontWeight:700, color:"#ff5252", background:"#ff525210", border:"1px solid #ff525230", padding:"2px 7px", borderRadius:4 }}>▼ 1.2%</span>
              </div>
              <div style={{ fontSize:10, color:"#37474f" }}>Vol $18.4M · Rank #112</div>
            </div>
          </div>
          <div style={{ overflow:"hidden", height:18, borderTop:"1px solid #0d0d1c", display:"flex", alignItems:"center" }}>
            <div style={{ display:"flex", animation:"TK 45s linear infinite", whiteSpace:"nowrap", fontSize:10, color:"#2e3c44" }}>
              {[1,2].map(k => <span key={k}>&nbsp;&nbsp;EGLD $4.10 ▼1.2%&nbsp;•&nbsp;STAKED 14.2M (50%)&nbsp;•&nbsp;APR 6.5%&nbsp;•&nbsp;INFLATION {s.inflRate}%&nbsp;•&nbsp;EMIT {s.dailyEmit}/DAY&nbsp;•&nbsp;BURN {s.dailyBurn}/DAY&nbsp;•&nbsp;SUPERNOVA TESTNET PHASE 2&nbsp;•&nbsp;ATH $545→$4.10 (−99.3%)&nbsp;•&nbsp;</span>)}
            </div>
          </div>
          <div style={{ display:"flex", overflowX:"auto", scrollbarWidth:"none" }}>
            {TABS.map(t => <button key={t} onClick={() => setTab(t)} style={{ padding:"9px 11px", fontSize:10, fontWeight:700, letterSpacing:1, textTransform:"uppercase", cursor:"pointer", color:tab===t?"#00e4d0":"#455a64", background:"transparent", border:"none", borderBottom:`2px solid ${tab===t?"#00e4d0":"transparent"}`, whiteSpace:"nowrap", transition:"all .2s" }}>{t}</button>)}
          </div>
        </div>

        {/* BODY */}
        <div style={{ flex:1, overflowY:"auto", padding:10, display:"flex", flexDirection:"column", gap:9 }}>

          {/* OVERVIEW */}
          {tab==="OVERVIEW" && <div style={{ animation:"FD .3s ease", display:"flex", flexDirection:"column", gap:9 }}>
            <div style={{ display:"flex", gap:8, overflowX:"auto", scrollbarWidth:"none", paddingBottom:2 }}>
              {[["Mkt Cap","$116.9M","#00e4d0"],["Staked","14.2M","#7c4dff"],["APR","6.5%","#00e676"],["Validators","3,200","#ffab00"],["Daily TXs","82,000","#ff6d00"],["TPS","15,000","#00bcd4"]].map(([l,v,c]) => (
                <div key={l} style={{ flexShrink:0, background:`${c}10`, border:`1px solid ${c}30`, borderRadius:8, padding:"8px 12px", textAlign:"center", minWidth:90 }}>
                  <div style={{ fontSize:9, color:"#455a64", letterSpacing:1, marginBottom:3 }}>{l.toUpperCase()}</div>
                  <div style={{ fontSize:15, fontWeight:800, color:c }}>{v}</div>
                </div>
              ))}
            </div>
            <div style={card}><div style={ct}>📈 PRICE ACTION</div><div style={g2}><Metric label="Current Price" value="$4.10" color="#00e4d0" sub="USDT pair"/><Metric label="From ATH" value="−99.3%" color="#ff5252" sub="ATH was $545"/><Metric label="Bear Case" value="$2.50–4.50" color="#ffab00" sub="Summer 2026"/><Metric label="Bull Case" value="$15–22" color="#00e676" sub="Summer 2026"/></div></div>
            <div style={card}><div style={ct}>⚡ ECOSYSTEM STATUS</div>
              {[["Supernova Upgrade","Testnet Phase 2","#ffab00"],["Google UCP","Integration Active","#00e676"],["Fear & Greed","28 — FEAR","#ff6d00"],["Network Dominance","0.009%","#7c4dff"],["Total Burned","248,000 EGLD","#00e4d0"]].map(([l,v,c]) => (
                <div key={l} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"7px 0", borderBottom:"1px solid #0d0d1c", fontSize:11 }}>
                  <span style={{ color:"#78909c" }}>{l}</span>
                  <span style={{ fontWeight:700, color:c, background:`${c}10`, border:`1px solid ${c}25`, padding:"2px 8px", borderRadius:4, fontSize:11 }}>{v}</span>
                </div>
              ))}
            </div>
            <div style={card}><div style={ct}>🔬 PROTOCOL v1.11.1</div><div style={g2}><Metric label="Inflation Rate" value={`${s.inflRate}%`} color="#7c4dff" sub={`Year ${s.year}`}/><Metric label="Fee Burn Ratio" value={`${s.burnRatio}%`} color="#ff6d00" sub="of tx fees"/><Metric label="Total Burned" value="248,000" color="#00e676" sub="EGLD all-time"/><Metric label="Hard Cap" value="28.5M" color="#00bcd4" sub="max supply"/></div></div>
          </div>}

          {/* BURN/EMIT */}
          {tab==="BURN/EMIT" && <div style={{ animation:"FD .3s ease", display:"flex", flexDirection:"column", gap:9 }}>
            <div style={card}><div style={ct}>🔥 LIVE BURN vs ⬆ EMIT</div>
              <div style={g2}><Metric label="Daily Emit" value={s.dailyEmit} color="#ff6d00" sub="EGLD / day"/><Metric label="Daily Burn" value={s.dailyBurn} color="#00e676" sub="EGLD / day (est.)"/><Metric label="Net Daily" value={(parseFloat(s.net)>0?"+":"")+s.net} color={parseFloat(s.net)>0?"#ff6d00":"#00e676"} sub={parseFloat(s.net)>0?"Inflationary":"Deflationary"}/><Metric label="Annual Emit" value={s.annualEmit} color="#7c4dff" sub="EGLD / year"/></div>
              <div style={{ marginTop:12 }}>
                <div style={{ display:"flex", justifyContent:"space-between", fontSize:10, marginBottom:4 }}><span style={{ color:"#ff6d00" }}>▮ EMIT {s.dailyEmit}</span><span style={{ color:"#00e676" }}>BURN {s.dailyBurn} ▮</span></div>
                <div style={{ height:9, background:"#14142a", borderRadius:5, overflow:"hidden", display:"flex" }}>
                  {(()=>{ const e=parseFloat(s.dailyEmit),b=parseFloat(s.dailyBurn),t=e+b,ep=t?(e/t)*100:50; return <><div style={{ width:`${ep}%`, background:"linear-gradient(90deg,#ff6d00,#ff1744)" }}/><div style={{ flex:1, background:"linear-gradient(90deg,#00b8a9,#00e676)" }}/></>; })()}
                </div>
              </div>
            </div>
            <div style={card}><div style={ct}>📊 10-YEAR PROJECTION</div>
              <ResponsiveContainer width="100%" height={185}>
                <AreaChart data={cd} margin={{ top:5, right:5, bottom:0, left:-22 }}>
                  <defs>
                    <linearGradient id="gE" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#ff6d00" stopOpacity={0.35}/><stop offset="95%" stopColor="#ff6d00" stopOpacity={0}/></linearGradient>
                    <linearGradient id="gB" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#00e676" stopOpacity={0.35}/><stop offset="95%" stopColor="#00e676" stopOpacity={0}/></linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#14142a"/>
                  <XAxis dataKey="yr" tick={{ fill:"#455a64", fontSize:8 }} interval={3}/>
                  <YAxis tick={{ fill:"#455a64", fontSize:8 }}/>
                  <Tooltip contentStyle={{ background:"#0a0a18", border:"1px solid #1a1a35", borderRadius:8, fontSize:11 }} labelStyle={{ color:"#00e4d0" }}/>
                  <Area type="monotone" dataKey="emit" stroke="#ff6d00" fill="url(#gE)" strokeWidth={2} name="Emit/day"/>
                  <Area type="monotone" dataKey="burn" stroke="#00e676" fill="url(#gB)" strokeWidth={2} name="Burn/day"/>
                </AreaChart>
              </ResponsiveContainer>
              <div style={{ display:"flex", gap:16, justifyContent:"center", marginTop:6 }}><span style={{ fontSize:10, color:"#ff6d00" }}>● Emit/day</span><span style={{ fontSize:10, color:"#00e676" }}>● Burn/day</span></div>
            </div>
            <div style={card}><div style={ct}>⚙ PROTOCOL CONSTANTS</div>
              {[["firstYearInflation","8.757%"],["inflationDecay","0.25%/yr"],["minInflation","2.000%"],["feeBurnStart","10%"],["feeBurnEnd","50% (Y8+)"],["hardCap","28,500,000"],["blocksPerDay","14,400"],["rewardSplit","50/20/20/10"],["currentYear",s.year],["burnRatioNow",`${s.burnRatio}%`]].map(([k,v]) => (
                <div key={k} style={{ display:"flex", justifyContent:"space-between", padding:"6px 0", borderBottom:"1px solid #0d0d1c", fontSize:11 }}>
                  <span style={{ color:"#455a64", fontFamily:"'JetBrains Mono',monospace" }}>{k}</span>
                  <span style={{ color:"#00e4d0", fontFamily:"'JetBrains Mono',monospace", fontWeight:700 }}>{v}</span>
                </div>
              ))}
            </div>
          </div>}

          {/* NEWS */}
          {tab==="NEWS" && <div style={{ animation:"FD .3s ease" }}>
            {!API_KEY && <div style={{ background:"#1a1a00", border:"1px solid #ffab0050", borderRadius:8, padding:"8px 12px", marginBottom:8, fontSize:11, color:"#ffab00" }}>⚠ Demo mode — add VITE_ANTHROPIC_API_KEY to .env for live AI news</div>}
            <div style={{ display:"flex", gap:6, overflowX:"auto", scrollbarWidth:"none", paddingBottom:6 }}>
              {["ALL","TRUE","SEMITRUE","UNVERIFIED","MISLEADING","FAKE","SPECULATIVE"].map(f => (
                <button key={f} onClick={() => setFilter(f)} style={{ flexShrink:0, fontSize:8, fontWeight:800, letterSpacing:.8, padding:"4px 9px", borderRadius:4, cursor:"pointer", background:filter===f?(BADGE[f]?.bg||"#0d0d20"):"#0a0a18", color:filter===f?(BADGE[f]?.color||"#fff"):"#455a64", border:`1px solid ${filter===f?(BADGE[f]?.border||"#455a64"):"#14142a"}`, transition:"all .15s" }}>
                  {f==="ALL"?"ALL":BADGE[f]?.label||f}
                </button>
              ))}
            </div>
            {loading && <div style={{ display:"flex", flexDirection:"column", alignItems:"center", padding:32, gap:10 }}>
              <div style={{ width:38, height:38, borderRadius:"50%", border:"3px solid #1a1a35", borderTop:"3px solid #00e4d0", animation:"SP .8s linear infinite" }}/>
              <span style={{ fontSize:11, color:"#455a64", letterSpacing:1 }}>SCANNING ALL SOURCES...</span>
            </div>}
            {!loading && news.length===0 && <div style={{ ...card, textAlign:"center", padding:36 }}>
              <div style={{ fontSize:40, marginBottom:10 }}>📡</div>
              <button onClick={load} style={{ background:"#00e4d015", border:"1px solid #00e4d0", color:"#00e4d0", padding:"10px 26px", borderRadius:9, fontSize:13, cursor:"pointer", fontWeight:700, letterSpacing:1 }}>⚡ SCAN ALL SOURCES</button>
            </div>}
            {!loading && fn.map(item => (
              <div key={item.id} onClick={() => setExp(exp===item.id?null:item.id)} style={{ background:"#07071a", border:`1px solid ${exp===item.id?(BADGE[item.credibility]?.border+"55"||"#14142a"):"#14142a"}`, borderRadius:10, padding:11, marginBottom:8, cursor:"pointer", transition:"border-color .2s" }}>
                <div style={{ display:"flex", justifyContent:"space-between", gap:8, marginBottom:6 }}>
                  <div style={{ fontSize:13, fontWeight:600, color:"#cfd8dc", lineHeight:1.4, flex:1 }}>{item.title}</div>
                  <div style={{ fontSize:8, fontWeight:800, letterSpacing:.8, padding:"3px 6px", borderRadius:4, border:`1px solid ${BADGE[item.credibility]?.border||"#455a64"}`, color:BADGE[item.credibility]?.color||"#455a64", background:BADGE[item.credibility]?.bg||"#1a1a2e", whiteSpace:"nowrap", flexShrink:0 }}>{BADGE[item.credibility]?.label||item.credibility}</div>
                </div>
                <div style={{ display:"flex", alignItems:"center", gap:7, flexWrap:"wrap" }}>
                  <span style={{ fontSize:10, fontWeight:700, color:SRC[item.source]||"#78909c", background:`${SRC[item.source]||"#78909c"}15`, padding:"2px 6px", borderRadius:3 }}>{item.source}</span>
                  <span style={{ fontSize:10, color:"#37474f" }}>{item.timeAgo}</span>
                  <span style={{ fontSize:10, fontWeight:700, color:item.priceImpact==="BULLISH"?"#00e676":item.priceImpact==="BEARISH"?"#ff5252":"#455a64" }}>{item.priceImpact==="BULLISH"?"▲ BULL":item.priceImpact==="BEARISH"?"▼ BEAR":"◆ NEUT"}</span>
                  <span style={{ fontSize:9, color:"#37474f", display:"flex", alignItems:"center", gap:3 }}>
                    <span style={{ display:"inline-block", width:5, height:5, borderRadius:"50%", background:item.confidence>70?"#00e676":item.confidence>40?"#ffab00":"#ff5252", boxShadow:`0 0 3px ${item.confidence>70?"#00e676":item.confidence>40?"#ffab00":"#ff5252"}` }}/>
                    {item.confidence}%
                  </span>
                </div>
                {exp===item.id && <div style={{ animation:"FD .2s ease" }}>
                  <div style={{ fontSize:11, color:"#546e7a", lineHeight:1.55, marginTop:8 }}>{item.summary}</div>
                  <div style={{ marginTop:8, padding:"7px 9px", background:"#050510", borderRadius:6, border:"1px solid #0d0d22", fontSize:10, color:"#37474f", fontStyle:"italic", lineHeight:1.5 }}>
                    <span style={{ color:BADGE[item.credibility]?.color||"#546e7a", fontStyle:"normal", fontWeight:700 }}>Analyst: </span>{item.reasoning}
                  </div>
                  {item.tags && <div style={{ display:"flex", gap:5, marginTop:8, flexWrap:"wrap" }}>{item.tags.map(t => <span key={t} style={{ fontSize:10, color:"#00e4d060", background:"#00e4d00d", padding:"2px 6px", borderRadius:3 }}>{t}</span>)}</div>}
                </div>}
              </div>
            ))}
            {!loading && news.length>0 && <button onClick={load} style={{ width:"100%", background:"#0a0a18", border:"1px solid #1a1a35", color:"#455a64", padding:12, borderRadius:10, fontSize:11, cursor:"pointer", fontWeight:700, letterSpacing:1 }}>⟳ REFRESH FEED</button>}
          </div>}

          {/* NETWORK */}
          {tab==="NETWORK" && <div style={{ animation:"FD .3s ease", display:"flex", flexDirection:"column", gap:9 }}>
            <div style={card}><div style={ct}>🌐 NETWORK HEALTH</div><div style={g2}>{[["Validators","3,200+","#00e4d0"],["Shards","3 + Meta","#7c4dff"],["Max TPS","15,000","#00e676"],["Block Time","~6s","#ffab00"],["Finality","<6s","#ff6d00"],["Uptime","99.99%","#00bcd4"]].map(([l,v,c]) => <Metric key={l} label={l} value={v} color={c}/>)}</div></div>
            <div style={card}><div style={ct}>💰 INFLATION SPLIT</div>
              {[["Community Rewards",50,"#00e676"],["Ecosystem Reserve",20,"#00e4d0"],["Foundation",20,"#7c4dff"],["Protocol Dev",10,"#ffab00"]].map(([l,p,c]) => (
                <div key={l} style={{ marginBottom:10 }}>
                  <div style={{ display:"flex", justifyContent:"space-between", fontSize:11, marginBottom:4 }}><span style={{ color:"#78909c" }}>{l}</span><span style={{ color:c, fontWeight:700 }}>{p}%</span></div>
                  <div style={{ background:"#0d0d20", borderRadius:3, height:7, overflow:"hidden" }}><div style={{ width:`${p}%`, height:"100%", background:c, borderRadius:3 }}/></div>
                </div>
              ))}
            </div>
            <div style={card}><div style={ct}>🔒 STAKING</div><div style={g2}><Metric label="Total Staked" value="14.2M EGLD" color="#7c4dff" sub="50% of supply"/><Metric label="Staking APR" value="6.5%" color="#00e676" sub="real yield"/><Metric label="Unbonding" value="10 days" color="#ff6d00" sub="lock period"/><Metric label="Min Stake" value="1 EGLD" color="#00e4d0" sub="delegated"/></div></div>
          </div>}

          {/* SENTIMENT */}
          {tab==="SENTIMENT" && <div style={{ animation:"FD .3s ease", display:"flex", flexDirection:"column", gap:9 }}>
            <div style={card}><div style={ct}>🧠 MARKET SENTIMENT</div>
              {[["Fear & Greed",28,"#ff6d00","FEAR"],["Social Volume",34,"#00e4d0","LOW"],["Dev Activity",71,"#00e676","HIGH"],["Whale Activity",45,"#7c4dff","MODERATE"],["Exchange Outflows",62,"#ffab00","BULLISH SIGN"]].map(([l,v,c,t]) => (
                <div key={l} style={{ marginBottom:10 }}>
                  <div style={{ display:"flex", justifyContent:"space-between", fontSize:11, marginBottom:4 }}><span style={{ color:"#78909c" }}>{l}</span><span style={{ color:c, fontWeight:700 }}>{v}/100 — {t}</span></div>
                  <div style={{ background:"#0d0d20", borderRadius:4, height:8, overflow:"hidden" }}><div style={{ width:`${v}%`, height:"100%", background:`linear-gradient(90deg,${c}70,${c})`, borderRadius:4 }}/></div>
                </div>
              ))}
            </div>
            <div style={card}><div style={ct}>🎯 PRICE TARGETS — SUMMER 2026</div>
              {[["Bear Case","$2.50–$4.50","#ff5252",35],["Base Case","$6–$12","#ffab00",45],["Bull Case","$15–$22","#00e676",20]].map(([sc,r,c,p]) => (
                <div key={sc} style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:10, background:"#050510", borderRadius:8, border:`1px solid ${c}18`, borderLeft:`3px solid ${c}`, marginBottom:8 }}>
                  <div><div style={{ fontSize:11, fontWeight:700, color:c }}>{sc}</div><div style={{ fontSize:18, fontWeight:800, color:"#fff", marginTop:2 }}>{r}</div></div>
                  <div style={{ width:44, height:44, borderRadius:"50%", border:`3px solid ${c}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:14, fontWeight:800, color:c, background:`${c}10` }}>{p}%</div>
                </div>
              ))}
              <div style={{ fontSize:10, color:"#2e3c44", fontStyle:"italic" }}>* Catalysts: Supernova mainnet, Google UCP AI commerce. Risk: 9.47% tail inflation.</div>
            </div>
            <div style={card}><div style={ct}>⚠ RISK MATRIX</div>
              {[["Tail inflation eroding trust","HIGH","#ff5252"],["Thin liquidity / low mkt cap","HIGH","#ff5252"],["Supernova mainnet delay","MEDIUM","#ffab00"],["SOL/SUI ecosystem rivalry","MEDIUM","#ffab00"],["Google UCP scope change","LOW","#00e676"],["Regulatory crackdown MVX","LOW","#00e676"]].map(([r,sev,c]) => (
                <div key={r} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"7px 0", borderBottom:"1px solid #0d0d1c", fontSize:11 }}>
                  <span style={{ color:"#78909c" }}>{r}</span>
                  <span style={{ fontSize:9, fontWeight:800, color:c, background:`${c}10`, border:`1px solid ${c}25`, padding:"2px 7px", borderRadius:3, letterSpacing:1 }}>{sev}</span>
                </div>
              ))}
            </div>
          </div>}

        </div>

        {/* BOTTOM NAV */}
        <div style={{ background:"#07070f", borderTop:"1px solid #1a1a35", padding:"7px 0 4px", display:"flex", justifyContent:"space-around", flexShrink:0 }}>
          {BNAV.map(b => (
            <button key={b.t} onClick={() => setTab(b.t)} style={{ background:"none", border:"none", cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:2, padding:"3px 8px" }}>
              <span style={{ fontSize:20, filter:tab===b.t?"none":"grayscale(1) opacity(.28)" }}>{b.i}</span>
              <span style={{ fontSize:9, color:tab===b.t?"#00e4d0":"#37474f", letterSpacing:.5 }}>{b.l}</span>
            </button>
          ))}
        </div>

      </div>
    </>
  );
}
